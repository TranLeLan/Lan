# EMG-Signal-Android-Application
#Bluetooth-Low-Energy
#real-time-line-chart
